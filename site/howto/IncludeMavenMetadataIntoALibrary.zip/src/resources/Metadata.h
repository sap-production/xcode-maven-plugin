//
//  Version.h
//


#define GROUP_ID @"${project.groupId}"
#define ARTIFACT_ID @"${project.artifactId}"
#define VERSION @"${project.version}"
#define CHANGELIST @"${changelist}"
