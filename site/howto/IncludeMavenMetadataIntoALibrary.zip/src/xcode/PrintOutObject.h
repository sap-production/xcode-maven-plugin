//
//  PrintOutObject.h
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface PrintOutObject : NSObject {

}

+(void)printout:(NSString*)theValue;
+(void)printout:(NSString*)theValue Label:(UILabel*)theLabel;
@end
