//
//  PrintOutObject.m
//

#import "PrintOutObject.h"
#import "Metadata.h"

@implementation PrintOutObject

+(void)printout:(NSString*)theValue{
	NSLog(@"%@", theValue);
}

+(void)printout:(NSString*)theValue Label:(UILabel*)theLabel{
	[theLabel setText:theValue];
	NSLog(@"In Label is shown:%@", theValue);
    NSLog(@"The library version is:%@:%@:%@.", GROUP_ID, ARTIFACT_ID, VERSION);
    NSLog(@"The changelist is: %@", CHANGELIST);
}
@end
