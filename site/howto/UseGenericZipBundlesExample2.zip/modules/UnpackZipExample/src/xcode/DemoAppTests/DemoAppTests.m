//
//  DemoAppTests.m
//  DemoAppTests
//
//  Created by Link, Alexander on 12/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "DemoAppTests.h"

@implementation DemoAppTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in DemoAppTests");
}

@end
